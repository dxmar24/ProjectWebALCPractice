const storageKey = "alc-hw08-state";

const branches = [
  { id: 1, name: "Matriz", director: "Juan Pablo Hidalgo" },
  { id: 2, name: "Norte", director: "Pending validation" },
  { id: 3, name: "Quitumbe", director: "Pending validation" },
  { id: 4, name: "Conocoto", director: "Pending validation" },
  { id: 5, name: "Tumbaco", director: "Pending validation" }
];

const initialState = {
  students: [
    { id: 1, fullName: "Camila Rojas", branchId: 1, level: "B1", scholarship: 0, status: "active", guardianName: "Maria Rojas" },
    { id: 2, fullName: "Mateo Vera", branchId: 2, level: "B1", scholarship: 50, status: "active", guardianName: "Patricia Vera" },
    { id: 3, fullName: "Valeria Paz", branchId: 3, level: "B2", scholarship: 100, status: "active", guardianName: "Luis Paz" },
    { id: 4, fullName: "Julian Mena", branchId: 4, level: "B2", scholarship: 75, status: "active", guardianName: "Andrea Mena" }
  ],
  attendance: [
    { personType: "student", personName: "Valeria Paz", date: "2026-05-03", status: "present", evidence: "ALC-20260503-1201" },
    { personType: "student", personName: "Mateo Vera", date: "2026-05-03", status: "late", evidence: "ALC-20260503-1202" },
    { personType: "teacher", personName: "Andrea Molina", date: "2026-05-03", status: "present", evidence: "ALC-20260503-1203" }
  ],
  classPlans: [],
  financeReports: [
    { branchId: 1, income: 2400, expenses: 920, matrixSharePercent: 0 },
    { branchId: 2, income: 1450, expenses: 530, matrixSharePercent: 15 }
  ],
  events: [
    { client: "Hotel Sol", type: "Private show", date: "2026-05-01", dancer: "Valeria Paz", gross: 180, deduction: 10 },
    { client: "Andina Group", type: "Corporate event", date: "2026-05-02", dancer: "Julian Mena", gross: 220, deduction: 0 }
  ],
  reserve: 850
};

let state = loadState();

function loadState() {
  const saved = localStorage.getItem(storageKey);

  if (!saved) {
    return structuredClone(initialState);
  }

  try {
    return JSON.parse(saved);
  } catch (error) {
    return structuredClone(initialState);
  }
}

function saveState() {
  localStorage.setItem(storageKey, JSON.stringify(state));
}

function branchName(branchId) {
  const branch = branches.find((item) => item.id === Number(branchId));
  return branch ? branch.name : "Pending";
}

function formatCurrency(value) {
  return `$${Number(value || 0).toLocaleString("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  })}`;
}

function fillBranchSelects() {
  document.querySelectorAll("#enrollBranch, #financeBranch").forEach((select) => {
    select.innerHTML = branches.map((branch) => (
      `<option value="${branch.id}">${branch.name}</option>`
    )).join("");
  });
}

function setDefaultDates() {
  const today = new Date().toISOString().slice(0, 10);
  const month = today.slice(0, 7);

  document.getElementById("attendanceDate").value = today;
  document.getElementById("eventDate").value = today;
  document.getElementById("planMonth").value = month;
}

function renderSnapshot() {
  const b2Count = state.students.filter((student) => student.level === "B2").length;
  const scholarshipCount = state.students.filter((student) => Number(student.scholarship) > 0).length;

  document.getElementById("totalStudents").textContent = state.students.length;
  document.getElementById("b2Students").textContent = b2Count;
  document.getElementById("scholarshipStudents").textContent = scholarshipCount;
  document.getElementById("reserveAmount").textContent = formatCurrency(state.reserve);
}

function renderStudents() {
  const rows = state.students.map((student) => `
    <tr>
      <td>${student.fullName}</td>
      <td>${branchName(student.branchId)}</td>
      <td><span class="badge level">${student.level}</span></td>
      <td>${student.scholarship}%</td>
      <td><span class="badge status">${student.status}</span></td>
    </tr>
  `);

  document.getElementById("studentsTable").innerHTML = rows.join("");
}

function renderParentSummary() {
  const latestStudents = state.students.slice(0, 3).map((student) => {
    const records = state.attendance.filter((item) => item.personName === student.fullName);
    const lastRecord = records.at(-1);

    return `
      <article class="summary-item">
        <strong>${student.fullName}</strong>
        <span>${student.level} | Scholarship ${student.scholarship}%</span>
        <span>Last attendance: ${lastRecord ? lastRecord.status : "No records yet"}</span>
      </article>
    `;
  });

  document.getElementById("parentSummary").innerHTML = latestStudents.join("");
}

function renderFinance() {
  const rows = state.financeReports.map((report) => {
    const matrixShare = report.income * (report.matrixSharePercent / 100);
    const netResult = report.income - report.expenses - matrixShare;

    return `
      <tr>
        <td>${branchName(report.branchId)}</td>
        <td>${formatCurrency(report.income)}</td>
        <td>${formatCurrency(report.expenses)}</td>
        <td>${formatCurrency(matrixShare)}</td>
        <td>${formatCurrency(netResult)}</td>
      </tr>
    `;
  });

  document.getElementById("financeTable").innerHTML = rows.join("");
}

function renderSettlements() {
  const grouped = state.events.reduce((result, event) => {
    if (!result[event.dancer]) {
      result[event.dancer] = {
        events: 0,
        gross: 0,
        deductions: 0
      };
    }

    result[event.dancer].events += 1;
    result[event.dancer].gross += Number(event.gross);
    result[event.dancer].deductions += Number(event.deduction);

    return result;
  }, {});

  const rows = Object.entries(grouped).map(([dancer, summary]) => `
    <article class="summary-item">
      <strong>${dancer}</strong>
      <span>Events attended: ${summary.events}</span>
      <span>Gross: ${formatCurrency(summary.gross)}</span>
      <span>Deductions: ${formatCurrency(summary.deductions)}</span>
      <span>Net payment: ${formatCurrency(summary.gross - summary.deductions)}</span>
    </article>
  `);

  document.getElementById("settlementList").innerHTML = rows.join("");
}

function renderRolePanels() {
  const selectedRole = document.getElementById("roleSelect").value;

  document.querySelectorAll(".role-panel").forEach((panel) => {
    const roles = panel.dataset.roles.split(" ");
    panel.hidden = !roles.includes(selectedRole);
  });
}

function renderAll() {
  renderSnapshot();
  renderStudents();
  renderParentSummary();
  renderFinance();
  renderSettlements();
  renderRolePanels();
}

function showMessage(id, text) {
  const message = document.getElementById(id);
  message.textContent = text;
  window.setTimeout(() => {
    message.textContent = "";
  }, 5000);
}

document.getElementById("enrollmentForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const student = {
    id: Date.now(),
    fullName: document.getElementById("enrollName").value.trim(),
    email: document.getElementById("enrollEmail").value.trim().toLowerCase(),
    phone: document.getElementById("enrollPhone").value.trim(),
    branchId: Number(document.getElementById("enrollBranch").value),
    level: document.getElementById("enrollLevel").value,
    scholarship: Number(document.getElementById("enrollScholarship").value),
    guardianName: document.getElementById("enrollGuardian").value.trim(),
    guardianPhone: document.getElementById("enrollGuardianPhone").value.trim(),
    notes: document.getElementById("enrollNotes").value.trim(),
    status: "pending"
  };

  state.students.push(student);
  saveState();
  renderAll();
  event.target.reset();
  fillBranchSelects();
  showMessage("enrollmentMessage", "Enrollment request saved.");

  window.alcSupabase.insert("students", {
    branch_id: student.branchId,
    full_name: student.fullName,
    email: student.email,
    phone: student.phone,
    level: student.level,
    scholarship_percent: student.scholarship,
    guardian_name: student.guardianName,
    guardian_phone: student.guardianPhone,
    status: "pending"
  }).catch((error) => showMessage("enrollmentMessage", error.message));
});

document.getElementById("classPlanForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const plan = {
    teacher: document.getElementById("planTeacher").value.trim(),
    month: document.getElementById("planMonth").value,
    level: document.getElementById("planLevel").value,
    objective: document.getElementById("planObjective").value.trim(),
    activities: document.getElementById("planActivities").value.trim()
  };

  state.classPlans.push(plan);
  saveState();
  event.target.reset();
  setDefaultDates();
  showMessage("planMessage", "Monthly class plan submitted.");

  window.alcSupabase.insert("class_plans", {
    branch_id: 1,
    teacher_name: plan.teacher,
    month: plan.month,
    level: plan.level,
    objective: plan.objective,
    activities: plan.activities,
    status: "submitted"
  }).catch((error) => showMessage("planMessage", error.message));
});

document.getElementById("attendanceForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const evidence = `ALC-${Date.now().toString().slice(-6)}`;
  const attendance = {
    personType: document.getElementById("attendanceType").value,
    personName: document.getElementById("attendanceName").value.trim(),
    date: document.getElementById("attendanceDate").value,
    status: document.getElementById("attendanceStatus").value,
    evidence
  };

  state.attendance.push(attendance);
  saveState();
  renderAll();
  event.target.reset();
  setDefaultDates();
  showMessage("attendanceMessage", `Attendance saved with evidence ${evidence}.`);

  window.alcSupabase.insert("attendance_records", {
    branch_id: 1,
    person_type: attendance.personType,
    person_name: attendance.personName,
    attendance_date: attendance.date,
    status: attendance.status,
    evidence_code: evidence
  }).catch((error) => showMessage("attendanceMessage", error.message));
});

document.getElementById("financeForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const month = new Date().toISOString().slice(0, 7);
  const report = {
    branchId: Number(document.getElementById("financeBranch").value),
    income: Number(document.getElementById("financeIncome").value),
    expenses: Number(document.getElementById("financeExpenses").value),
    matrixSharePercent: Number(document.getElementById("financeShare").value),
    month
  };

  state.financeReports.push(report);
  state.reserve += report.income * (report.matrixSharePercent / 100);
  saveState();
  renderAll();

  window.alcSupabase.insert("branch_finance_reports", {
    branch_id: report.branchId,
    month: report.month,
    income: report.income,
    expenses: report.expenses,
    matrix_share_percent: report.matrixSharePercent
  }).catch(() => {});
});

document.getElementById("eventForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const professionalEvent = {
    client: document.getElementById("eventClient").value.trim(),
    type: document.getElementById("eventType").value.trim(),
    date: document.getElementById("eventDate").value,
    dancer: document.getElementById("eventDancer").value.trim(),
    gross: Number(document.getElementById("eventAmount").value),
    deduction: Number(document.getElementById("eventDeduction").value)
  };

  state.events.push(professionalEvent);
  saveState();
  renderAll();
  event.target.reset();
  setDefaultDates();
  showMessage("eventMessage", "B2 professional event registered.");

  window.alcSupabase.insert("professional_events", {
    branch_id: 1,
    client_name: professionalEvent.client,
    event_type: professionalEvent.type,
    event_date: professionalEvent.date,
    total_amount: professionalEvent.gross,
    status: "paid"
  }).catch((error) => showMessage("eventMessage", error.message));
});

document.getElementById("roleSelect").addEventListener("change", renderRolePanels);

document.getElementById("resetDemo").addEventListener("click", () => {
  state = structuredClone(initialState);
  saveState();
  renderAll();
});

fillBranchSelects();
setDefaultDates();
renderAll();
