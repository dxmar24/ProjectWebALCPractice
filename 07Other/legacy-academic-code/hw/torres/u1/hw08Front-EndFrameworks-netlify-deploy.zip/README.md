# HW08 - Front-End Frameworks

This assignment contains the functional frontend for **American Latin Class**.

The page is built with HTML, CSS, and JavaScript. It works as a small single-page application and can be deployed directly to Netlify.

## Included Modules

- Public landing page for visitors.
- Enrollment form for new students.
- Role selector for visitor, administrator, parent, teacher, branch director, and general director views.
- Student table with B1/B2 level and scholarship percentage.
- Parent section with attendance summary.
- Teacher monthly class planning form.
- Student and teacher attendance form.
- Branch finance summary.
- B2 professional event and dancer settlement demo.

## Run Locally

Open `index.html` in a browser.

The app works immediately with local demo data through `localStorage`.

## Supabase Setup

1. Open Supabase SQL Editor.
2. Run `database/supabase_schema.sql`.
3. Edit `script/supabase-client.js`.
4. Replace `YOUR_SUPABASE_URL` and `YOUR_SUPABASE_ANON_KEY`.

The app still works without Supabase, but Supabase is required for the real database version.

## Deploy to Netlify

The folder is ready for Netlify.

Option A:

1. Go to Netlify.
2. Create a new site.
3. Drag and drop this folder.

Option B:

```powershell
npx netlify-cli deploy --prod --dir .
```

Netlify deployment requires a Netlify login or token, so I cannot publish it from this computer unless those credentials are available.

